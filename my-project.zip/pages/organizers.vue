<script setup>
import NavBar from "@/components/NavBar.vue";
import Footer from "@/components/Footer.vue";
</script>

<template>
  <div>
    <NavBar />
    <section class="py-16 px-8 text-center">
      <h1 class="text-4xl font-bold">Информация для организаторов</h1>
      <p class="mt-4 text-gray-600">
        Организуйте свое мероприятие в ретрит-центре Соната.
      </p>
    </section>
    <Footer />
  </div>
</template>
