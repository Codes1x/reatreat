<script setup>
import HeroSection from "@/components/HeroSection.vue";
import CenterFeatures from "@/components/CenterFeatures.vue";
import NearbyPlaces from "@/components/NearbyPlaces.vue";
import OrganizerGuestSection from "@/components/OrganizerGuestSection.vue";
import ReviewsSection from "@/components/ReviewsSection.vue";
import ContactForm from "@/components/ContactForm.vue";
import ContactUs from "@/components/ContactUs.vue";
import HowToGet from "@/components/HowToGet.vue";
</script>

<template>
  <div>
    <HeroSection />
    <CenterFeatures />
    <OrganizerGuestSection />
    <NearbyPlaces />
    <ReviewsSection />
    <ContactForm />
    <HowToGet />
    <ContactUs />
  </div>
</template>
