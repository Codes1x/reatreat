<template>
    <section class="py-16 bg-white">
      <div class="max-w-6xl mx-auto px-4 text-center">
        <h2 class="text-3xl font-extrabold text-gray-900 sm:text-4xl">
          Рядом с нами находятся
        </h2>
        <p class="mt-4 text-lg text-gray-600">
          Уникальные места и достопримечательности в шаговой доступности.
        </p>
      </div>
  
      <div class="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        <div
          v-for="(place, index) in places"
          :key="index"
          class="bg-gray-100 rounded-xl shadow-md p-6 flex flex-col items-start transition-transform transform hover:-translate-y-2 hover:shadow-lg duration-300"
        >
          <div class="flex items-center space-x-3">
            <MapPinIcon class="w-6 h-6 text-blue-500" />
            <span class="text-sm font-medium text-gray-700">
              {{ place.distance }}
            </span>
          </div>
          <h3 class="mt-3 text-lg font-semibold text-gray-900">
            {{ place.title }}
          </h3>
          <p class="mt-2 text-gray-600 text-sm leading-relaxed">
            {{ place.description }}
          </p>
        </div>
      </div>
    </section>
  </template>
  
  <script setup>
  import { MapPinIcon } from "@heroicons/vue/24/solid";
  
  const places = [
    {
      title: "Развалины Византийского храма",
      description: "На самой вершине 300-метровой горы.",
      distance: "1.5 км от нас",
    },
    {
      title: "Набережная «Горный воздух»",
      description: "Один из лучших пляжей в Большом Сочи для отдыхающих.",
      distance: "600 м от нас",
    },
    {
      title: "Аквапарк АкваЛоо",
      description: "Единственный из аквапарков Черноморского побережья, который работает круглый год.",
      distance: "1 км от нас",
    },
    {
      title: "Церковь Симона Кананита",
      description: "Одно из главных украшений курортного поселка.",
      distance: "3 км от нас",
    },
    {
      title: "Дача доктора Павлова (1907 год)",
      description: "Самая красивая дача в округе Сочи.",
      distance: "3.1 км от нас",
    },
    {
      title: "Лестница Шереметева",
      description: "Лестница к бывшему дому графа.",
      distance: "5.8 км от нас",
    },
  ];
  </script>
  