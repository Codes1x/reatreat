<template>
    <section class="container mx-auto px-4 py-12 lg:py-20">
      <section class="bg-white py-12">
        <!-- Левая часть -->
        <h1 class="text-5xl font-bold text-green-600 mb-4">
          <h1 class="text-4xl lg:text-5xl font-extrabold text-gray-900 leading-tight">
            <span class="text-blue-600">Ретритный центр</span> в Сочи
          </h1>
          <p class="mt-4 text-gray-600 text-lg">
            Место силы для благостного отдыха с мощной энергетикой реликтового леса, идеально подходит для:
          </p>
  
          <div class="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div v-for="feature in features" :key="feature.name" class="flex items-center gap-4 p-4 bg-white shadow-md rounded-lg">
              <component :is="feature.icon" class="w-6 h-6 text-blue-600"/>
              <span class="text-lg font-medium">{{ feature.name }}</span>
            </div>
          </div>
  
          <button class="px-6 py-3 bg-white/20 backdrop-blur-md text-white font-semibold rounded-lg shadow-lg hover:bg-white/30 transition">
  Подробнее
</button>

        </div>
  
        <!-- Видео -->
        <div class="relative w-full h-full">
          <div class="w-full h-full aspect-w-16 aspect-h-9">
            <iframe
              class="w-full h-full object-cover border-0 outline-none"
              src="https://player.vimeo.com/video/82701136"
              frameborder="0"
              allowfullscreen
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  </template>
  
  <script setup>
  import { GlobeAltIcon, SparklesIcon, MusicalNoteIcon, BoltIcon, HeartIcon, UserGroupIcon } from '@heroicons/vue/24/outline';
  
  const features = [
    { name: "Ретриты", icon: GlobeAltIcon },
    { name: "Практики", icon: SparklesIcon },
    { name: "Фестивали", icon: MusicalNoteIcon },
    { name: "Йога-туры", icon: UserGroupIcon },
    { name: "Медитации", icon: BoltIcon },
    { name: "Здоровый отдых", icon: HeartIcon }
  ];
  </script>
  