<template>
    <section class="relative bg-gradient-to-r from-blue-500 to-purple-600 text-white py-20">
      <div class="container mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 items-center px-6">
        
        <!-- Текстовая часть -->
        <div>
          <h1 class="text-5xl font-bold mb-6 leading-tight">
            Пространство для ваших мероприятий
          </h1>
          <p class="text-lg opacity-90 mb-6">
            Идеальное место для проведения ретритов, духовных практик, тренингов, йога-туров,
            мастер-классов, фестивалей и других мероприятий. Мы позаботились о вашем комфорте.
          </p>
  
          <!-- Преимущества -->
          <ul class="space-y-4 mb-6">
            <li class="flex items-center">
              <CheckCheck class="w-6 h-6 text-green-300 mr-3" />
              Полное сопровождение и поддержка мероприятий
            </li>
            <li class="flex items-center">
              <CheckCheck class="w-6 h-6 text-green-300 mr-3" />
              PR-продвижение ваших программ и событий
            </li>
            <li class="flex items-center">
              <CheckCheck class="w-6 h-6 text-green-300 mr-3" />
              Просторные залы и природные площадки
            </li>
          </ul>
  
          <!-- Кнопка -->
          <button class="bg-white text-blue-600 px-6 py-3 rounded-lg shadow-lg hover:bg-blue-100 transition">
            Узнать больше
          </button>
        </div>
  
        <!-- Видео -->
        <div class="w-full h-full aspect-w-16 aspect-h-9">
            <iframe
              class="w-full h-full object-cover border-0 outline-none"
              src="https://player.vimeo.com/video/82701136"
              frameborder="0"
              allowfullscreen
            ></iframe>
          </div>
      </div>
    </section>
  </template>
  
  <script setup>

import { CheckCheck } from "lucide-vue-next";
  </script>
  