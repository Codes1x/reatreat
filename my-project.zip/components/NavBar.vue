<template>
  <nav class="bg-white shadow-md fixed top-0 left-0 w-full z-50">
    <div class="container mx-auto px-4 flex justify-between items-center py-3">
      <!-- Логотип -->
      <NuxtLink to="/" class="text-xl font-bold text-black">
        <span class="text-black">Ретрит центр</span> <span class="text-blue-600">Соната</span>
      </NuxtLink>

      <!-- Меню -->
      <div class="hidden md:flex space-x-6">
        <NuxtLink to="/" class="text-gray-700 hover:text-blue-600">Главная</NuxtLink>
        <NuxtLink to="/organizers" class="text-gray-700 hover:text-blue-600">Организаторам</NuxtLink>
        <NuxtLink to="/" class="text-gray-700 hover:text-blue-600">Для гостей</NuxtLink>
        <NuxtLink to="/" class="text-gray-700 hover:text-blue-600">Длительное проживание</NuxtLink>
        <NuxtLink to="/" class="text-gray-700 hover:text-blue-600">Контакты</NuxtLink>
      </div>

      <!-- Контакты и соцсети -->
      <div class="hidden md:flex items-center space-x-4">
        <a href="tel:+79234567890" class="flex items-center text-gray-700 hover:text-blue-600">
          <PhoneIcon class="w-5 h-5 mr-1" />
          +7 (923) 456-78-90
        </a>
        <a href="https://wa.me/79234567890" target="_blank" class="text-green-500 hover:text-green-600">
          <MessageCircleIcon class="w-6 h-6" />
        </a>
        <a href="https://t.me/yourtelegram" target="_blank" class="text-blue-500 hover:text-blue-600">
          <SendIcon class="w-6 h-6" />
        </a>
      </div>

      <!-- Мобильное меню -->
      <button @click="isOpen = !isOpen" class="md:hidden text-gray-700">
        <MenuIcon class="w-6 h-6" />
      </button>
    </div>

    <!-- Всплывающее мобильное меню -->
    <div v-if="isOpen" class="md:hidden bg-white shadow-md absolute top-full left-0 w-full">
      <NuxtLink to="/" class="block py-3 px-4 text-gray-700 hover:bg-gray-100">Главная</NuxtLink>
      <NuxtLink to="/organizers" class="block py-3 px-4 text-gray-700 hover:bg-gray-100">Организаторам</NuxtLink>
      <NuxtLink to="/" class="block py-3 px-4 text-gray-700 hover:bg-gray-100">Для гостей</NuxtLink>
      <NuxtLink to="/" class="block py-3 px-4 text-gray-700 hover:bg-gray-100">Длительное проживание</NuxtLink>
      <NuxtLink to="/" class="block py-3 px-4 text-gray-700 hover:bg-gray-100">Контакты</NuxtLink>
      <a href="tel:+79234567890" class="block py-3 px-4 text-gray-700 hover:bg-gray-100">+7 (923) 456-78-90</a>
      <div class="flex justify-center space-x-4 py-3">
        <a href="https://wa.me/79234567890" target="_blank" class="text-green-500 hover:text-green-600">
          <MessageCircleIcon class="w-6 h-6" />
        </a>
        <a href="https://t.me/yourtelegram" target="_blank" class="text-blue-500 hover:text-blue-600">
          <SendIcon class="w-6 h-6" />
        </a>
      </div>
    </div>
  </nav>
</template>

<script setup>
import { ref } from "vue";
import { MenuIcon, PhoneIcon, MessageCircleIcon, SendIcon } from "lucide-vue-next";

const isOpen = ref(false);
</script>
